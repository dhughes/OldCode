vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|15 Sep 2005 12:42:55 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|15 Sep 2005 12:42:55 -0000
vti_filesize:IR|2781
